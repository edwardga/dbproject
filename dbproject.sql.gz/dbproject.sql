-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- 主機: localhost
-- 建立日期: Jan 18, 2011, 11:35 �W��
-- 伺服器版本: 5.1.41
-- PHP 版本: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 資料庫: `dbproject`
--

-- --------------------------------------------------------

--
-- 資料表格式： `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `account_id` varchar(45) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `password` varchar(45) CHARACTER SET utf8 NOT NULL,
  `type` varchar(30) CHARACTER SET utf8 NOT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 列出以下資料庫的數據： `account`
--

INSERT INTO `account` (`account_id`, `password`, `type`, `type_id`) VALUES
('edwardga', '123456', 'artist', 0),
('nanmadol', '123456', 'audience', 0),
('niwi', '202cb962ac59075b964b07152d234b70', 'audience', 1);

-- --------------------------------------------------------

--
-- 資料表格式： `artist`
--

CREATE TABLE IF NOT EXISTS `artist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `debut_time` year(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=8 ;

--
-- 列出以下資料庫的數據： `artist`
--


-- --------------------------------------------------------

--
-- 資料表格式： `audience`
--

CREATE TABLE IF NOT EXISTS `audience` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- 列出以下資料庫的數據： `audience`
--

INSERT INTO `audience` (`id`, `name`, `phone`) VALUES
(1, 'åŠ‰', '0988878738'),
(2, 'æž—å¸æ¡“', '0988878738'),
(3, 'æ±Ÿç”°å³¶å¹³å…«', '0926938535');

-- --------------------------------------------------------

--
-- 資料表格式： `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aud_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `post` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 AUTO_INCREMENT=1 ;

--
-- 列出以下資料庫的數據： `comment`
--


-- --------------------------------------------------------

--
-- 資料表格式： `instrument`
--

CREATE TABLE IF NOT EXISTS `instrument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `introduction` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=4 ;

--
-- 列出以下資料庫的數據： `instrument`
--

INSERT INTO `instrument` (`id`, `name`, `category`, `introduction`) VALUES
(1, '小提琴', '弦樂', '四條弦....blablabla'),
(2, '中提琴', '弦樂', '四條弦，較小提琴大'),
(3, '大提琴', '弦樂', '較小提琴中提琴大，四條弦，台灣著名大提琴家"馬友友"');

-- --------------------------------------------------------

--
-- 資料表格式： `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=3 ;

--
-- 列出以下資料庫的數據： `location`
--

INSERT INTO `location` (`id`, `name`, `address`) VALUES
(1, '小巨蛋', '台北市松山區南京東路四段2號'),
(2, '城市舞台', '臺北市八德路三段25號');

-- --------------------------------------------------------

--
-- 資料表格式： `myfavorite`
--

CREATE TABLE IF NOT EXISTS `myfavorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aud_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `score` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 AUTO_INCREMENT=1 ;

--
-- 列出以下資料庫的數據： `myfavorite`
--


-- --------------------------------------------------------

--
-- 資料表格式： `myshow`
--

CREATE TABLE IF NOT EXISTS `myshow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ar_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `post_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 AUTO_INCREMENT=1 ;

--
-- 列出以下資料庫的數據： `myshow`
--


-- --------------------------------------------------------

--
-- 資料表格式： `sellsystem`
--

CREATE TABLE IF NOT EXISTS `sellsystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `homepage` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 列出以下資料庫的數據： `sellsystem`
--

INSERT INTO `sellsystem` (`id`, `name`, `homepage`, `phone`) VALUES
(1, '年代售票', 'http://www.ticket.com.tw/', '02-23419898'),
(2, '兩廳院售票', 'http://www.artsticket.com.tw/CKSCC2005/Home/Home00/index.aspx', '02-3393-9888');

-- --------------------------------------------------------

--
-- 資料表格式： `show`
--

CREATE TABLE IF NOT EXISTS `show` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `day` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `l_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `sell_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 列出以下資料庫的數據： `show`
--

INSERT INTO `show` (`id`, `name`, `day`, `time`, `l_id`, `style_id`, `sell_id`) VALUES
(1, '尾牙', '2011-01-18', '00:00:00', 2, 2, 1);

-- --------------------------------------------------------

--
-- 資料表格式： `showstyle`
--

CREATE TABLE IF NOT EXISTS `showstyle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `statement` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=4 ;

--
-- 列出以下資料庫的數據： `showstyle`
--

INSERT INTO `showstyle` (`id`, `name`, `statement`) VALUES
(1, '爵士', ''),
(2, '流行音樂', ''),
(3, '古典樂', '');

-- --------------------------------------------------------

--
-- 資料表格式： `show_instrument`
--

CREATE TABLE IF NOT EXISTS `show_instrument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `in_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=3 ;

--
-- 列出以下資料庫的數據： `show_instrument`
--

INSERT INTO `show_instrument` (`id`, `in_id`, `s_id`) VALUES
(1, 1, 1),
(2, 1, 2);

-- --------------------------------------------------------

--
-- 資料表格式： `show_song`
--

CREATE TABLE IF NOT EXISTS `show_song` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_id` int(11) NOT NULL,
  `song_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 AUTO_INCREMENT=1 ;

--
-- 列出以下資料庫的數據： `show_song`
--


-- --------------------------------------------------------

--
-- 資料表格式： `song`
--

CREATE TABLE IF NOT EXISTS `song` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `creative_time` date DEFAULT NULL,
  `composer` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 列出以下資料庫的數據： `song`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
