-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- 主機: localhost
-- 建立日期: Jan 20, 2011, 02:37 �W��
-- 伺服器版本: 5.1.41
-- PHP 版本: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 資料庫: `dbproject`
--
CREATE DATABASE `dbproject` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbproject`;

-- --------------------------------------------------------

--
-- 資料表格式： `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `account_id` varchar(45) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `password` varchar(45) CHARACTER SET utf8 NOT NULL,
  `type` varchar(30) CHARACTER SET utf8 NOT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 列出以下資料庫的數據： `account`
--

INSERT INTO `account` (`account_id`, `password`, `type`, `type_id`) VALUES
('123', '202cb962ac59075b964b07152d234b70', 'audience', 3),
('aaaa', '74b87337454200d4d33f80c4663dc5e5', 'audience', 2),
('eason', 'e10adc3949ba59abbe56e057f20f883e', 'artist', 4),
('edwardga', '81dc9bdb52d04dc20036dbd8313ed055', 'artist', 2),
('nanmadol', 'e10adc3949ba59abbe56e057f20f883e', 'audience', 1),
('qwer', '81dc9bdb52d04dc20036dbd8313ed055', 'artist', 3),
('s', '03c7c0ace395d80182db07ae2c30f034', 'audience', 4),
('toast', 'e10adc3949ba59abbe56e057f20f883e', 'artist', 1);

-- --------------------------------------------------------

--
-- 資料表格式： `artist`
--

CREATE TABLE IF NOT EXISTS `artist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `debut_time` year(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=5 ;

--
-- 列出以下資料庫的數據： `artist`
--

INSERT INTO `artist` (`id`, `name`, `debut_time`) VALUES
(1, '林司桓', 1989),
(2, 'edwardga', 1990),
(3, 'qaz', 1990),
(4, '陳奕迅', 1995);

-- --------------------------------------------------------

--
-- 資料表格式： `audience`
--

CREATE TABLE IF NOT EXISTS `audience` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- 列出以下資料庫的數據： `audience`
--

INSERT INTO `audience` (`id`, `name`, `phone`) VALUES
(1, '大尾', '0913243289'),
(2, 'aaaa', '0987665421'),
(3, '123', '123'),
(4, 's', 's');

-- --------------------------------------------------------

--
-- 資料表格式： `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(255) NOT NULL,
  `s_id` int(11) NOT NULL,
  `post` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=15 ;

--
-- 列出以下資料庫的數據： `comment`
--

INSERT INTO `comment` (`id`, `account_id`, `s_id`, `post`, `title`) VALUES
(1, 'edwardga', 13, 'qwertyuiop', 'wtf'),
(3, 'edwardga', 13, 'im tired lol', 'crycry'),
(4, 's', 9, '123', 'test'),
(5, 's', 9, '111', '111'),
(6, 's', 9, 'zsxdcf', 'crycry'),
(7, 'edwardga', 11, 'dsfa', 'crycry'),
(8, 'edwardga', 11, '123`13', 'asd'),
(9, 'edwardga', 11, 'eqweqwe', '醞釀'),
(10, 'edwardga', 11, 'qweqwe', '111'),
(11, 'edwardga', 11, 'qweqwe', 'qweqwe'),
(12, 'edwardga', 11, 'asdsahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 'asdasd'),
(13, 'toast', 12, '這實在是太瘋狂了', '哇哈哈'),
(14, '', 7, '測試測試', '哈哈');

-- --------------------------------------------------------

--
-- 資料表格式： `guestbook`
--

CREATE TABLE IF NOT EXISTS `guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `time` datetime NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- 列出以下資料庫的數據： `guestbook`
--

INSERT INTO `guestbook` (`id`, `account_id`, `time`, `content`, `title`) VALUES
(1, 'edwardga', '2011-01-20 08:25:52', '快要練球了', '想睡覺'),
(2, '', '2011-01-20 08:36:54', '123', '123'),
(3, 'edwardga', '2011-01-20 08:37:15', '寫完了!!!', '救命'),
(4, 'toast', '2011-01-20 09:25:16', 'blablabla', '拉肚子');

-- --------------------------------------------------------

--
-- 資料表格式： `instrument`
--

CREATE TABLE IF NOT EXISTS `instrument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `introduction` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=20 ;

--
-- 列出以下資料庫的數據： `instrument`
--

INSERT INTO `instrument` (`id`, `name`, `category`, `introduction`) VALUES
(1, '電吉他', '弦樂', '電吉他迷人之處，在於它的伴奏性、音色創造性及造型都有很大的發揮空間。音色的多樣化是電吉他最好玩的其中一部份，可以透過不同類型音色型態的效果器,發出不同的音色。'),
(2, '鋼琴', '弦樂', '源自西洋古典音樂中的一種鍵盤樂器，普遍用於獨奏、重奏、伴奏等演出，用於作曲和排練音樂十分方便。鋼琴的音域寬廣，音色宏亮、清脆，富於變化，表現力很強。獨奏時，可演奏各種氣勢磅礡、寬廣、抒情的音樂，亦可演奏歡快、靈巧、技巧性很高的華彩樂段。'),
(3, '小提琴', '弦樂', '屬於弓弦樂器，是現代管弦樂團弦樂組中最重要的樂器。作為現代弦樂器中最具份量的樂器，小提琴主要的特點在於其輝煌的聲音、高度的演奏技巧和豐富、廣泛的表現力。又被稱作為樂器中的女王。'),
(4, '爵士鼓', '打擊樂', '是一套打擊樂器的複合體，集合多種打擊樂器為一身，主要在搖滾樂，爵士樂中被應用。'),
(5, '二胡', '弦樂', '是中國的一種民族弓弦樂器，過去主要流行於長江中下游一帶，所以又稱為南胡。集中於中高音域的表現，音色接近人聲，情感表現力極高，廣為大眾接受。二胡多用於民間絲竹音樂演奏或民歌、戲曲的伴奏。'),
(6, '薩克斯風', '管樂', '是一種木管樂器，但是管體通常是用黃銅製造，使得薩克斯風同時具有銅管類樂器的特性。薩克斯風以其煙斗狀的外形為人所熟知。薩克斯風是高靈活性低約束性的樂器，有時也會讓人有過於自我表現而不夠內斂的印象。這也是薩克斯在古典樂中出現相對較少而多在爵士樂或搖滾樂為人喜愛的原因之一。'),
(7, '小號', '管樂', '俗稱小喇叭，銅管樂器家族的一員，常負責旋律部分或高吭節奏的演奏，也是銅管樂器家族中音域最高的樂器。常用於軍樂隊、管弦樂團、管樂團、爵士大樂團或一般爵士樂，視曲目編制需求而有不同。'),
(8, '豎琴', '管樂', '是一種大型撥弦樂器，是現代管弦樂團的重要樂器之一。豎琴可作獨奏、重奏和合奏，屬多功能的複音樂器。其流傳地區甚廣，在歐洲、美洲和亞洲等地區亦有出現豎琴類的樂器。'),
(9, '長笛', '管樂', '是現代管弦樂和室內樂中主要的高音旋律樂器，外型是一根開有數個音孔的圓柱型長管。。不同材料的長笛完全根據演奏者的愛好選擇。但是在樂隊中應該統一使用一種長笛，以得到最和諧和飽滿的音響效果。'),
(10, '貝斯', '弦樂', '現代搖滾樂團組合的主要樂器。在樂隊中，貝斯在節奏上扮演一個重要的角色。自1950年始，貝斯在流行曲中很大程度上取代了低音提琴，適用於很多不同的風格，包括搖滾樂、重金屬音樂、藍調、爵士樂中的低音部。'),
(11, '單簧管', '管樂', '又稱豎笛、黑管，是木管樂器的一種。從大約1780年起，它被一些最大的管絃樂隊採用。。單簧管擁有極闊的音域，幾乎能涵蓋人聲的絕大部份範圍，更難得是它無論在任何的音區吹奏，音量的大細都能控制自如。此外，單簧管在不同音區都有獨特的音色：低音區深沉，中音區渾厚，高音區明亮。音色又接近人聲，所以適合表現各種不同的音樂性格，是樂隊中不可缺少的組成部分。'),
(12, '長號', '管樂', '又名伸縮號或伸縮喇叭，是銅管樂器的成員之一，利用一條可以伸縮長短的彎管來發出高、低不同的音調，是所有管樂器中唯一可以不使用活塞按鍵來產生音樂的樂器。長號能表現出一種不同於其他銅管樂器的較為粗獷直接、雄厚的音色，這也是許多樂曲中不可或缺的元素之一；而當表現溫暖的音色時，又能帶有另一種粗獷的味道。'),
(13, '口琴', '管樂', '又稱Gaita，用嘴吹或吸氣，使金屬簧片振動發聲的多簧片樂器。在樂器分類上屬於自由簧的吹奏樂器，而多簧片的結構，使口琴具有演奏和聲的基礎，因此可用以演奏各種類型的音樂。'),
(14, '笙', '管樂', '是中國古老的簧管樂器，在古代八音的樂器分類中，笙屬於匏類。藉由每根管子中的簧片發聲，是吹管樂器中唯一的和聲樂器，也是唯一能吹吸發聲的樂器，其音色清晰透亮，音域寬廣，感染力強。由於笙可以吹奏和弦，在現代國樂團，笙可以擔當旋律或伴奏的作用。'),
(15, '笛子', '管樂', '是中國傳統音樂中常用的橫吹木管樂器之一，一般分為南方的曲笛和北方的梆笛。笛子常在中國民間音樂、戲曲、中國民族樂團、西洋交響樂團和現代音樂中運用，是中國音樂的代表樂器之一。大部分笛子是竹製的，但也有木製笛、石笛和玉笛。'),
(16, '吉他', '弦樂', '屬於彈撥樂器，通常有六條弦，形狀與提琴相似。吉他在流行音樂、搖滾音樂、藍調、民歌、佛朗明哥中，常被視為主要樂器。而在古典音樂的領域裡，吉他常以獨奏或二重奏的型式演出；當然，在室內樂和管弦樂中，吉他亦扮演著相當程度的陪襯角色。'),
(17, '木琴', '打擊樂', '是打擊樂器的一種。將木製琴鍵置於共鳴管之上，以琴棒敲打以產生旋律。琴鍵排列方式類似於鋼琴鍵盤。一般所指的木琴為高音木琴，琴鍵較窄，音域較高，音色清脆。'),
(18, '手風琴', '管樂', '是一件附有鍵盤的自由簧風琴族樂器。現代手風琴有兩種，鋼琴式手風琴比較容易上手，常作為學習鋼琴的基礎，可以演奏各種古典或現代音樂，巴揚手風琴音域廣，由於鍵鈕小，手移動速度快，可以演奏許多高速度高難度樂曲，總體以演奏俄羅斯，愛爾蘭民樂為主。'),
(19, '大提琴', '弦樂', '是一種弓弦樂器，在室內樂多為獨奏角色，另也擔任管弦樂團中弦樂的部分。演奏方式有持弓劃弦，或作撥奏、敲奏等其他奏法。在管弦樂團、弦樂四重奏或室內樂團所演奏的音樂中，皆扮演著不可或缺的重要角色，此外也有許多由大提琴所擔任演出的協奏曲及奏鳴曲。');

-- --------------------------------------------------------

--
-- 資料表格式： `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=17 ;

--
-- 列出以下資料庫的數據： `location`
--

INSERT INTO `location` (`id`, `name`, `address`) VALUES
(1, '台北小巨蛋', '台北市松山區南京東路四段2號'),
(2, '城市舞台', '臺北市八德路三段25號'),
(3, '國家音樂廳', '台北市中山南路 21-1 號'),
(4, '台大體育館', '台北市羅斯福路四段1號'),
(5, '河岸留言', '台北市羅斯福路三段244巷2號B1'),
(6, 'The Wall', '台北市羅斯福路四段200號B1 '),
(7, '女巫店', '台北市新生南路三段56巷7號'),
(8, '國父紀念館', '台北市信義區仁愛路四段505號'),
(9, '敦南誠品', '台北市敦化南路一段245號2F'),
(10, '南港101', '台北市南港區興南街71號'),
(11, '中山堂', '台北市延平南路98號'),
(12, '新舞台', '台北市松壽路3號'),
(13, '北藝大', '台北市北投區學園路1號'),
(14, '西門紅樓', '台北市萬華區成都路10號'),
(15, '二二八公園', '台北市中正區凱達格蘭大道3號'),
(16, '國際會議中心', '台北市信義路五段1號');

-- --------------------------------------------------------

--
-- 資料表格式： `myfavorite`
--

CREATE TABLE IF NOT EXISTS `myfavorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(45) CHARACTER SET utf8 NOT NULL,
  `s_id` int(11) NOT NULL,
  `score` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=49 ;

--
-- 列出以下資料庫的數據： `myfavorite`
--

INSERT INTO `myfavorite` (`id`, `account_id`, `s_id`, `score`) VALUES
(42, 's', 13, 1),
(46, 's', 8, 2),
(47, 's', 9, 5),
(48, 's', 11, 2);

-- --------------------------------------------------------

--
-- 資料表格式： `myfavsong`
--

CREATE TABLE IF NOT EXISTS `myfavsong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(45) CHARACTER SET utf8 NOT NULL,
  `s_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- 列出以下資料庫的數據： `myfavsong`
--


-- --------------------------------------------------------

--
-- 資料表格式： `sellsystem`
--

CREATE TABLE IF NOT EXISTS `sellsystem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `homepage` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- 列出以下資料庫的數據： `sellsystem`
--

INSERT INTO `sellsystem` (`id`, `name`, `homepage`, `phone`) VALUES
(1, '年代售票', 'http://www.ticket.com.tw/', '02-23419898'),
(2, '兩廳院售票', 'http://www.artsticket.com.tw/CKSCC2005/Home/Home00/index.aspx', '02-3393-9888'),
(3, '寬宏售票', 'http://www.kham.com.tw/', '07-780-9900'),
(4, '博客來售票', 'http://tickets.books.com.tw/', '02-2653-5588'),
(5, 'FamiTicket', 'https://www.famiticket.com.tw/', '02-6618-2822 '),
(6, '玫瑰大眾售票', 'http://www.g-music.iticket.com.tw/', '0800-000-802'),
(7, '無售票', '', '');

-- --------------------------------------------------------

--
-- 資料表格式： `show`
--

CREATE TABLE IF NOT EXISTS `show` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `day` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `l_id` int(11) DEFAULT NULL,
  `style_id` int(11) DEFAULT NULL,
  `sell_id` int(11) DEFAULT NULL,
  `ar_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- 列出以下資料庫的數據： `show`
--

INSERT INTO `show` (`id`, `name`, `day`, `time`, `l_id`, `style_id`, `sell_id`, `ar_id`) VALUES
(1, '尾牙', '2011-01-18', '00:00:00', 2, 2, 1, 0),
(2, '資管之夜', '2011-01-12', NULL, 2, 2, 1, 0),
(3, '大尾打呼秀', '2011-01-16', '01:30:00', 1, 1, 2, 2),
(5, '吐司尾巴', '2011-01-28', '00:00:00', 2, 3, 1, NULL),
(6, '李永裕講台語', '2011-01-20', '01:30:00', 2, 1, 1, NULL),
(7, 'yo!battle', '2011-01-20', '12:00:00', 2, 2, 2, 3),
(9, '嫂子賣餃子2', '1990-02-26', '12:00:00', 1, 1, 1, 2),
(10, '', '0000-00-00', '00:00:00', 0, 0, 0, 2),
(11, 'DBdemo', '2011-01-20', '16:00:00', 2, 3, 2, 2),
(12, 'DBdemo', '2011-01-20', '16:00:00', 2, 3, 2, 2),
(15, 'DUO陳奕迅2011演唱會 ', '2011-01-15', '19:30:00', 1, 1, 1, 4);

-- --------------------------------------------------------

--
-- 資料表格式： `show_instrument`
--

CREATE TABLE IF NOT EXISTS `show_instrument` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `in_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=19 ;

--
-- 列出以下資料庫的數據： `show_instrument`
--

INSERT INTO `show_instrument` (`id`, `in_id`, `s_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 7, 2),
(4, 8, 1),
(5, 2, 9),
(6, 3, 11),
(7, 3, 11),
(8, 1, 13),
(9, 2, 13),
(10, 3, 13),
(11, 1, 15),
(12, 2, 15),
(13, 4, 15),
(14, 16, 15),
(15, 1, 15),
(16, 2, 15),
(17, 4, 15),
(18, 16, 15);

-- --------------------------------------------------------

--
-- 資料表格式： `showstyle`
--

CREATE TABLE IF NOT EXISTS `showstyle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `statement` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=ucs2 AUTO_INCREMENT=10 ;

--
-- 列出以下資料庫的數據： `showstyle`
--

INSERT INTO `showstyle` (`id`, `name`, `statement`) VALUES
(1, 'Pop', '亦稱流行歌曲、現代流行音樂，是指廣泛被大眾所接受和喜歡的音樂。現代流行音樂又可作商業化運作，有時稱作商業音樂。'),
(2, '爵士', '是一種起源於非洲形成於美國的音樂形式，這些音樂是美國黑人根植於其非洲音樂傳統的基礎上，結合他們在現實中的遭遇創作出來的。爵士樂在其發展過程中除了有黑人音樂的根源外，還吸收了如古典音樂、民族音樂等諸多音樂元素，逐漸形成了今天多門多類的爵士樂，所傳遞的內容也更為多樣。'),
(3, '搖滾', '是流行音樂的一種形式，通常由顯著的人聲伴以吉他、鼓和貝斯演出，很多形態的搖滾樂也使用鍵盤樂器，如風琴、鋼琴、電子琴或合成器。搖滾樂經常有強勁的強拍，圍繞電吉他，空心電吉他，以及木吉他展開。'),
(4, '新世紀', '是一種在1970年代出現的一種音樂形式，最早用於幫助冥思及潔浄心靈，但許多後期的創作者已不再抱有這種出發點。另一種說法是：由於其豐富多彩、富於變換，不同於以前任何一種音樂；它是一個範疇，一切不同以往，象徵時代更替詮釋精神內涵的改良音樂都可歸於此內，所以被命名為New Age。'),
(5, '鄉村', '是一種當代的流行音樂，起源於美國南部與阿帕拉契山區。鄉村音樂的根源可追溯至1920年代，融合了傳統民謠音樂、凱爾特音樂、福音音樂及古時音樂。'),
(6, '嘻哈', '是一種音樂的風格，誕生於美國1970年代，並於1980年代成為大眾流行文化之一。包含兩個主要部份Rapping，和DJ。伴隨著嘻哈舞蹈(尤其是霹靂舞)和街頭藝術(尤其是塗鴉)，構成嘻哈音樂的四個元素。'),
(7, '電音', '廣義而言，任何以電子合成器、效果器、電腦音樂軟體、鼓機等「樂器」所產生的電子聲響，只要是使用電子設備所創造的音樂，包括Techno、Trance、House等音樂類型，都可以是電音。'),
(8, '古典', '是一個獨立的流派，藝術手法講求洗練，追求理性地表達情感。按廣義的古典音樂定義：從17世紀到19世紀的專業音樂創作來看，印象派音樂和現代音樂皆不屬古典音樂之類；若按嚴格的古典音樂定義，則古典是指海頓、莫扎特、貝多芬等人的音樂作品。'),
(9, 'R&B', '融合了爵士樂、福音音樂和藍調音樂的音樂形式。在1960年代，節奏藍調被用於總括靈魂樂和放克音樂的術語。而現在R&B的縮寫差不多一直被用於代替全寫「節奏藍調」。');

-- --------------------------------------------------------

--
-- 資料表格式： `song`
--

CREATE TABLE IF NOT EXISTS `song` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `style_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `Content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `ar_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- 列出以下資料庫的數據： `song`
--

INSERT INTO `song` (`id`, `name`, `style_id`, `Content`, `ar_id`) VALUES
(3, '123', '1', '123', 2),
(5, '十年', '1', '十年這首歌應該是寫一對情人的故事,兩個人在一起沒有明天,所以只好忍痛分手,\r\n想起十年前兩個人都還在別人的懷抱,互不相識,後來有緣相遇相知相愛,奈何上天注定不能長相廝守,只好分手,兩個人重又變為陌生人,回到十年前的原點.這是一種很無奈的心痛,也是一種傷心的感慨.無奈啊,希望來生他們會在一起吧.', 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
